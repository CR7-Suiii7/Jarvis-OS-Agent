import os
import json
import sqlite3
import numpy as np
import logging
from typing import List, Dict, Any, Optional
from google.genai import types

logger = logging.getLogger(__name__)

class MemoryManager:
    """
    Manages the learning layer for Jarvis.
    Handles semantic memory (user preferences), coding style guide optimization,
    and system action execution logs.
    """
    def __init__(
        self,
        db_path: str = ".secrets/history.db",
        memory_path: str = ".secrets/semantic_memory.json",
        style_path: str = ".secrets/style_guide.json",
        llm_client: Any = None
    ):
        self.db_path = os.path.normpath(db_path)
        self.memory_path = os.path.normpath(memory_path)
        self.style_path = os.path.normpath(style_path)
        self.llm_client = llm_client
        
        # Ensure target directories exist
        for path in [self.db_path, self.memory_path, self.style_path]:
            dir_name = os.path.dirname(path)
            if dir_name and not os.path.exists(dir_name):
                os.makedirs(dir_name, exist_ok=True)
                
        # Initialize sub-components
        self._init_sqlite()
        self._init_style_guide()
        self._load_semantic_memory()

    # ==========================================
    # 1. Action History Log (SQLite)
    # ==========================================
    def _init_sqlite(self) -> None:
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS actions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    action_type TEXT NOT NULL,
                    details TEXT NOT NULL,
                    success INTEGER NOT NULL,
                    error_message TEXT
                )
            """)
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Failed to initialize SQLite history database: {e}")

    def log_action(self, action_type: str, details: str, success: bool, error_message: str = "") -> None:
        """
        Record a system command, email action, or project request to SQLite.
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO actions (action_type, details, success, error_message) VALUES (?, ?, ?, ?)",
                (action_type, details, 1 if success else 0, error_message)
            )
            conn.commit()
            conn.close()
            logger.info(f"Logged action '{action_type}' (Success: {success})")
        except Exception as e:
            logger.error(f"Failed to log action to SQLite: {e}")

    def get_failed_actions(self, action_type: str, limit: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve recent execution failures for an action type to learn alternative strategies.
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                "SELECT timestamp, details, error_message FROM actions WHERE action_type = ? AND success = 0 ORDER BY timestamp DESC LIMIT ?",
                (action_type, limit)
            )
            rows = cursor.fetchall()
            conn.close()
            return [dict(r) for r in rows]
        except Exception as e:
            logger.error(f"Failed to fetch failed actions: {e}")
            return []

    # ==========================================
    # 2. Coding Style Guide (JSON)
    # ==========================================
    def _init_style_guide(self) -> None:
        if not os.path.exists(self.style_path):
            default_style = {
                "naming_conventions": "Follow standard snake_case for functions and variables, and PascalCase for classes.",
                "documentation": "Include brief descriptive docstrings and parameter type hints for all public methods.",
                "general_preferences": [
                    "Write modular, single-responsibility functions.",
                    "Always structure projects with a main.py entry point."
                ]
            }
            try:
                with open(self.style_path, "w", encoding="utf-8") as f:
                    json.dump(default_style, f, indent=4)
            except Exception as e:
                logger.error(f"Failed to initialize default style guide: {e}")

    def get_style_guide(self) -> Dict[str, Any]:
        """
        Load and return the current coding style guide.
        """
        try:
            if os.path.exists(self.style_path):
                with open(self.style_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load style guide: {e}")
        return {}

    def refine_style_guide(self, generated_code: str, feedback: str = "") -> str:
        """
        Uses Gemini to compare code against the style guide, extracts improvements,
        and updates style_guide.json with the refined rules.
        """
        current_style = self.get_style_guide()
        if not self.llm_client or not self.llm_client.client:
            return "Style guide refinement skipped (LLM client offline or missing)."

        prompt = (
            f"You are an expert Python developer and code reviewer.\n"
            f"Examine the following code sample and user feedback, and compare it to the current coding style guide:\n\n"
            f"--- Current Style Guide ---\n{json.dumps(current_style, indent=2)}\n\n"
            f"--- Code Sample ---\n{generated_code}\n\n"
            f"--- User Feedback ---\n{feedback}\n\n"
            f"Identify any recurring style preferences, formatting rules, or best practices shown in this code/feedback.\n"
            f"Merge them into the current style guide.\n"
            f"Return ONLY a clean JSON object containing the updated rules with keys: "
            f"'naming_conventions', 'documentation', and 'general_preferences'."
        )

        try:
            # Generate content using the raw Client object in self.llm_client
            response = self.llm_client.client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    temperature=0.1
                )
            )
            
            if response.text:
                new_style = json.loads(response.text.strip())
                if all(k in new_style for k in ["naming_conventions", "documentation", "general_preferences"]):
                    with open(self.style_path, "w", encoding="utf-8") as f:
                        json.dump(new_style, f, indent=4)
                    return f"Style guide refined successfully. General preferences: {new_style.get('general_preferences', [])}"
                else:
                    return "Style guide refinement failed: Returned JSON structure was invalid."
            return "Style guide refinement failed: Empty model response."
        except Exception as e:
            logger.error(f"Error refining style guide: {e}")
            return f"Error during style guide refinement: {str(e)}"

    # ==========================================
    # 3. Semantic Memory (JSON Vector Store)
    # ==========================================
    def _load_semantic_memory(self) -> None:
        self.memory_db: List[Dict[str, Any]] = []
        if os.path.exists(self.memory_path):
            try:
                with open(self.memory_path, "r", encoding="utf-8") as f:
                    self.memory_db = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load semantic memory from file: {e}")

    def _save_semantic_memory(self) -> None:
        try:
            with open(self.memory_path, "w", encoding="utf-8") as f:
                json.dump(self.memory_db, f, indent=4)
        except Exception as e:
            logger.error(f"Failed to save semantic memory to file: {e}")

    def _get_embedding(self, text: str) -> Optional[List[float]]:
        """
        Query Gemini's embed_content API to generate vector coordinates.
        """
        if not self.llm_client or not self.llm_client.client:
            logger.warning("Gemini Client is missing. Embeddings computation skipped.")
            return None
        try:
            response = self.llm_client.client.models.embed_content(
                model="text-embedding-004",
                contents=text
            )
            if response.embeddings:
                return response.embeddings[0].values
            return None
        except Exception as e:
            logger.error(f"Failed to compute text embedding via Gemini: {e}")
            return None

    def add_preference(self, text: str) -> bool:
        """
        Add a preference snippet along with its embedding to the local vector store.
        """
        embedding = self._get_embedding(text)
        if embedding is None:
            return False
            
        self.memory_db.append({
            "text": text,
            "embedding": embedding
        })
        self._save_semantic_memory()
        logger.info(f"Stored user preference: '{text}'")
        return True

    def get_relevant_preferences(self, query: str, limit: int = 3, threshold: float = 0.5) -> List[str]:
        """
        Embeds the search query, computes cosine similarity against
        all stored vectors, and returns matching preference texts.
        """
        if not self.memory_db:
            return []
            
        query_vector = self._get_embedding(query)
        if query_vector is None:
            return []

        matches = []
        for item in self.memory_db:
            pref_vector = item["embedding"]
            
            # Compute cosine similarity using numpy
            v1 = np.array(query_vector)
            v2 = np.array(pref_vector)
            
            dot = np.dot(v1, v2)
            norm_v1 = np.linalg.norm(v1)
            norm_v2 = np.linalg.norm(v2)
            
            if norm_v1 == 0 or norm_v2 == 0:
                sim = 0.0
            else:
                sim = float(dot / (norm_v1 * norm_v2))
                
            if sim >= threshold:
                matches.append((item["text"], sim))
                
        # Sort by similarity descending
        matches.sort(key=lambda x: x[1], reverse=True)
        return [text for text, _ in matches[:limit]]
