import logging
from typing import List, Callable, Any
from google import genai
from google.genai import types
from core.config import settings

logger = logging.getLogger(__name__)

class GeminiClient:
    """
    Wrapper for Google GenAI SDK to interface with Gemini models.
    Supports tool registration and content generation loops.
    """
    def __init__(self):
        self.api_key = settings.gemini_api_key
        if not self.api_key or self.api_key == "your_gemini_api_key_here":
            logger.warning("GEMINI_API_KEY is not set. Google GenAI calls will fail.")
            self.client = None
        else:
            try:
                self.client = genai.Client(api_key=self.api_key)
            except Exception as e:
                logger.error(f"Failed to initialize Google GenAI Client: {e}")
                self.client = None

    def query(
        self,
        contents: Any,
        tools: List[Callable],
        system_instruction: str
    ) -> Any:
        """
        Query the Gemini model with a list of tools and a system instruction.
        
        Args:
            contents: A single prompt string or a list of Content/Part objects representing chat history.
            tools: List of Python functions that the model is allowed to invoke.
            system_instruction: System prompt configuration for the model.
        """
        if not self.client:
            raise ValueError(
                "Gemini Client is uninitialized. Please update 'GEMINI_API_KEY' in your .env file."
            )
            
        config = types.GenerateContentConfig(
            tools=tools,
            system_instruction=system_instruction,
            temperature=0.0 # Use 0.0 for deterministic tool routing
        )
        
        return self.client.models.generate_content(
            model="gemini-2.5-flash",
            contents=contents,
            config=config
        )
