import logging
from typing import List, Dict, Callable, Any
from google.genai import types

from modules.base import BaseModule
from core.llm import GeminiClient
from core.security import security_manager
from core.memory import MemoryManager

logger = logging.getLogger(__name__)

class JarvisCore:
    """
    Main orchestrator for Jarvis.
    Registers modules/tools and coordinates user queries, LLM tool routing,
    and execution feedback loop.
    """
    def __init__(self):
        self.llm_client = GeminiClient()
        import os
        from core.config import settings
        data_dir = settings.jarvis_data_dir
        self.memory_manager = MemoryManager(
            db_path=os.path.join(data_dir, "history.db"),
            memory_path=os.path.join(data_dir, "semantic_memory.json"),
            style_path=os.path.join(data_dir, "style_guide.json"),
            llm_client=self.llm_client
        )
        self.modules: Dict[str, BaseModule] = {}
        self.tools_map: Dict[str, Callable] = {
            "add_user_preference": self.add_user_preference
        }
        self.history: List[types.Content] = []
        
        self.system_instruction = (
            "You are Jarvis, a highly capable, secure, modular voice assistant.\n"
            "You have access to a set of local system and remote account integration tools.\n"
            "When a user asks for an action that requires a tool, call the appropriate tool.\n"
            "Always be concise and structured in your responses as you are a voice assistant.\n"
            "If the user asks you to perform a task that involves a shell command or file operations "
            "that could be destructive, note that the security layer will prompt them for confirmation.\n"
            "Speak directly to the user."
        )

    def add_user_preference(self, preference: str) -> str:
        """
        Record a new user preference or coding style guideline to semantic memory.
        
        Args:
            preference: The text describing the user's preference or choice.
        """
        success = self.memory_manager.add_preference(preference)
        if success:
            return f"Successfully saved preference: '{preference}' to my semantic memory."
        return "Failed to save preference to semantic memory."


    def register_module(self, module: BaseModule) -> None:
        """
        Registers a module and maps its exposed tools for routing.
        """
        self.modules[module.name] = module
        for tool in module.get_tools():
            tool_name = tool.__name__
            if tool_name in self.tools_map:
                logger.warning(f"Overwriting duplicate tool name: {tool_name}")
            self.tools_map[tool_name] = tool
            logger.info(f"Registered tool '{tool_name}' from module '{module.name}'")

    def get_registered_tools(self) -> List[Callable]:
        """Returns all registered tool functions."""
        return list(self.tools_map.values())

    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> str:
        """
        Executes a registered tool by name with provided arguments.
        """
        action_type = "tool_execution"
        if "shell" in tool_name or "command" in tool_name:
            action_type = "command"
        elif "project" in tool_name:
            action_type = "project"
        elif "email" in tool_name or "event" in tool_name or "calendar" in tool_name:
            action_type = "email_calendar"

        if tool_name not in self.tools_map:
            err_msg = f"Error: Tool '{tool_name}' is not registered."
            self.memory_manager.log_action(action_type, f"Tool: {tool_name}, Args: {arguments}", success=False, error_message=err_msg)
            return err_msg

        tool_func = self.tools_map[tool_name]
        try:
            # Execute python function with unpack arguments
            result = tool_func(**arguments)
            self.memory_manager.log_action(action_type, f"Tool: {tool_name}, Args: {arguments}", success=True)
            
            # Code Optimization Loop: Refine style guide after project generation
            if tool_name == "create_and_push_project" and "base_dir" in arguments and "project_name" in arguments:
                import os
                proj_path = os.path.normpath(os.path.join(arguments["base_dir"], arguments["project_name"]))
                main_py = os.path.join(proj_path, "main.py")
                if os.path.exists(main_py):
                    try:
                        with open(main_py, "r", encoding="utf-8") as f:
                            code_content = f.read()
                        refinement_msg = self.memory_manager.refine_style_guide(
                            generated_code=code_content,
                            feedback="Analyzing new project template boilerplate code structure."
                        )
                        print(f"\n[Learning Layer] Style Refinement Output: {refinement_msg}")
                    except Exception as re:
                        logger.error(f"Failed to execute code style guide refinement: {re}")

            return str(result)

        except TypeError as te:
            err_msg = f"Error: Invalid arguments for tool '{tool_name}'. Details: {str(te)}"
            logger.error(f"Argument mismatch executing {tool_name}: {te}")
            self.memory_manager.log_action(action_type, f"Tool: {tool_name}, Args: {arguments}", success=False, error_message=err_msg)
            return err_msg
        except Exception as e:
            err_msg = f"Error executing tool '{tool_name}': {str(e)}"
            logger.error(f"Error executing tool {tool_name}: {e}")
            self.memory_manager.log_action(action_type, f"Tool: {tool_name}, Args: {arguments}", success=False, error_message=err_msg)
            return err_msg


    def handle_query(self, user_query: str) -> str:
        """
        Processes a user query by querying Gemini, running tool requests in a loop,
        and returning the final assistant response.
        Loads memory and preference injection dynamically for each turn.
        """
        if not user_query:
            return "I did not receive any input."

        tools = self.get_registered_tools()
        
        # 1. Fetch relevant user preferences from semantic memory
        prefs = self.memory_manager.get_relevant_preferences(user_query, limit=3, threshold=0.55)
        
        # 2. Fetch active coding style guide rules
        style = self.memory_manager.get_style_guide()
        
        # 3. Retrieve recent execution failures to learn/adapt
        failures = (
            self.memory_manager.get_failed_actions("command", limit=2) +
            self.memory_manager.get_failed_actions("project", limit=2)
        )
        
        # 4. Construct adaptive dynamic system prompt instructions
        dynamic_instruction = self.system_instruction
        if style:
            dynamic_instruction += (
                f"\n\nCoding Style Guide (Must apply these rules to code creation):\n"
                f"- Naming Conventions: {style.get('naming_conventions')}\n"
                f"- Documentation: {style.get('documentation')}\n"
                f"- General Preferences:\n"
            )
            dynamic_instruction += "\n".join(f"  * {rule}" for rule in style.get("general_preferences", []))
            
        if prefs:
            dynamic_instruction += "\n\nUser Preferences (Relevant to current context):\n"
            dynamic_instruction += "\n".join(f"- {pref}" for pref in prefs)
            
        if failures:
            dynamic_instruction += (
                "\n\nHistorical Command/Action Failures (Avoid repeating these errors. "
                "Suggest alternative paths or correction strategies):\n"
            )
            for f in failures:
                dynamic_instruction += f"- Details: '{f['details']}' | Error: '{f['error_message']}'\n"

        # Build local context for this generation run
        session_history = list(self.history)
        session_history.append(types.Content(
            role="user",
            parts=[types.Part.from_text(text=user_query)]
        ))

        try:
            # Initial LLM query with adaptive system prompt
            response = self.llm_client.query(
                contents=session_history,
                tools=tools,
                system_instruction=dynamic_instruction
            )
            
            # Loop for function calling / tool orchestration
            # The model may choose to call multiple tools or call tools sequentially
            while response.function_calls:
                # Add model's tool call turn to history
                model_content = response.candidates[0].content
                session_history.append(model_content)
                
                response_parts = []
                for call in response.function_calls:
                    print(f"\n[Jarvis Core] Executing tool: '{call.name}'")
                    # Run the tool locally
                    tool_result = self.execute_tool(call.name, call.args)
                    
                    # Store response part
                    part = types.Part.from_function_response(
                        name=call.name,
                        response={"result": tool_result}
                    )
                    response_parts.append(part)
                
                # Append tool results as a single user content turn
                tool_content = types.Content(
                    role="user",
                    parts=response_parts
                )
                session_history.append(tool_content)
                
                # Send the outcomes back to Gemini to complete its reasoning
                response = self.llm_client.query(
                    contents=session_history,
                    tools=tools,
                    system_instruction=dynamic_instruction
                )
            
            # Extract final text answer
            if response.text:
                final_text = response.text
                
                # Record conversation turn in persistent history
                self.history.append(types.Content(
                    role="user",
                    parts=[types.Part.from_text(text=user_query)]
                ))
                self.history.append(types.Content(
                    role="model",
                    parts=[types.Part.from_text(text=final_text)]
                ))
                return final_text
            
            return "I completed the action but have no verbal response."

        except Exception as e:
            logger.error(f"Error handling query in JarvisCore: {e}")
            return f"An error occurred while processing your request: {str(e)}"

