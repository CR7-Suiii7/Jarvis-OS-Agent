import logging
from typing import Callable, Optional

logger = logging.getLogger(__name__)

class SecurityManager:
    """
    Core security manager for Jarvis.
    Enforces Human-in-the-Loop confirmations for destructive/sensitive actions
    and validates environmental secrets.
    """
    def __init__(self):
        # A list of dangerous patterns that MUST prompt confirmation
        self.dangerous_commands = [
            "rm ", "del ", "rd ", "format ", "mkfs ", "dd ",
            "sudo", "shutdown", "reboot", "init ", "kill ", "pkill",
            "mv ", "ren "
        ]
        self._confirm_callback: Optional[Callable[[str], bool]] = None

    def set_confirm_callback(self, callback: Callable[[str], bool]):
        """Override how confirmation is requested (e.g. voice vs CLI)."""
        self._confirm_callback = callback

    def is_command_dangerous(self, command: str) -> bool:
        """Checks if a command matches any dangerous patterns."""
        cmd_lower = command.lower().strip()
        
        # Check for exact matches or prefix matches in commands
        for pattern in self.dangerous_commands:
            if pattern in cmd_lower:
                return True
        return False

    def confirm_action(self, action_description: str) -> bool:
        """
        Request Human-in-the-loop confirmation for an action.
        Returns True if approved, False otherwise.
        """
        print(f"\n[SECURITY ALERT] Confirmation required for:\n>>> {action_description}")
        
        if self._confirm_callback:
            try:
                return self._confirm_callback(action_description)
            except Exception as e:
                logger.error(f"Error in confirmation callback: {e}")
        
        # Fallback to standard CLI prompt
        try:
            response = input("Proceed with this action? (yes/no) [no]: ").strip().lower()
            return response in ["y", "yes", "proceed", "approve"]
        except (KeyboardInterrupt, EOFError):
            return False

security_manager = SecurityManager()
