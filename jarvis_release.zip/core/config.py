import os
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    gemini_api_key: str = Field(default="", validation_alias="GEMINI_API_KEY")
    github_token: str = Field(default="", validation_alias="GITHUB_TOKEN")
    jarvis_data_dir: str = Field(default=".secrets", validation_alias="JARVIS_DATA_DIR")
    google_credentials_file: str = Field(default=".secrets/credentials.json", validation_alias="GOOGLE_CREDENTIALS_FILE")
    google_token_file: str = Field(default=".secrets/token.json", validation_alias="GOOGLE_TOKEN_FILE")
    tts_rate: int = Field(default=200, validation_alias="TTS_RATE")
    tts_volume: float = Field(default=1.0, validation_alias="TTS_VOLUME")


    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

# Instantiate settings
settings = Settings()
