import os
import datetime
from typing import List, Callable
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

from modules.base import BaseModule
from core.config import settings

class GoogleIntegrator(BaseModule):
    """
    Module integrating Gmail and Google Calendar APIs.
    Performs secure local token storage and authentication using OAuth2.
    """
    SCOPES = [
        "https://www.googleapis.com/auth/gmail.readonly",
        "https://www.googleapis.com/auth/calendar.readonly"
    ]

    @property
    def name(self) -> str:
        return "GoogleIntegrator"

    @property
    def description(self) -> str:
        return "Manage and query Google Gmail and Calendar events."

    def get_tools(self) -> List[Callable]:
        return [
            self.fetch_unread_emails,
            self.list_today_events
        ]

    def _get_credentials(self) -> Credentials:
        """
        Authenticate the user and return valid Google OAuth2 credentials.
        Saves tokens locally under the configured path for subsequent runs.
        """
        creds = None
        token_path = os.path.normpath(settings.google_token_file)
        creds_path = os.path.normpath(settings.google_credentials_file)

        # Ensure secrets folder exists
        secrets_dir = os.path.dirname(token_path)
        if secrets_dir and not os.path.exists(secrets_dir):
            os.makedirs(secrets_dir, exist_ok=True)

        # Try to load existing token
        if os.path.exists(token_path):
            try:
                creds = Credentials.from_authorized_user_file(token_path, self.SCOPES)
            except Exception:
                creds = None

        # Request new token if existing one is missing or invalid
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                except Exception:
                    creds = None
            
            if not creds:
                if not os.path.exists(creds_path):
                    raise FileNotFoundError(
                        f"Google credentials file not found at '{creds_path}'. "
                        "Please download 'credentials.json' from Google Cloud Console (OAuth 2.0 Desktop Application client), "
                        "save it to the directory, and ensure your .env path config matches."
                    )
                flow = InstalledAppFlow.from_client_secrets_file(creds_path, self.SCOPES)
                creds = flow.run_local_server(port=0)
            
            # Save the refreshed/new token for next run
            with open(token_path, "w", encoding="utf-8") as token_file:
                token_file.write(creds.to_json())

        return creds

    def fetch_unread_emails(self, max_results: int = 5) -> str:
        """
        Fetches unread emails from the primary inbox.

        Args:
            max_results: The maximum number of unread email snippets to fetch (default: 5).
        """
        try:
            creds = self._get_credentials()
            service = build("gmail", "v1", credentials=creds)
            
            results = service.users().messages().list(
                userId="me",
                q="is:unread",
                maxResults=max_results
            ).execute()
            
            messages = results.get("messages", [])
            if not messages:
                return "No unread emails found."

            email_summary = []
            for msg_meta in messages:
                msg = service.users().messages().get(userId="me", id=msg_meta["id"], format="metadata", metadataHeaders=["Subject", "From"]).execute()
                headers = msg.get("payload", {}).get("headers", [])
                
                subject = "No Subject"
                sender = "Unknown Sender"
                for h in headers:
                    if h["name"] == "Subject":
                        subject = h["value"]
                    elif h["name"] == "From":
                        sender = h["value"]
                
                snippet = msg.get("snippet", "")
                email_summary.append(f"- **From**: {sender}\n  **Subject**: {subject}\n  **Snippet**: {snippet}\n")
                
            return "\n".join(email_summary)
        except FileNotFoundError as fnf:
            return str(fnf)
        except Exception as e:
            return f"Error retrieving emails: {str(e)}"

    def list_today_events(self, max_results: int = 10) -> str:
        """
        Retrieves today's calendar events from the user's primary calendar.

        Args:
            max_results: The maximum number of calendar events to fetch (default: 10).
        """
        try:
            creds = self._get_credentials()
            service = build("calendar", "v3", credentials=creds)

            # Get local timezone and today's boundaries
            now = datetime.datetime.now()
            start_of_today = datetime.datetime(now.year, now.month, now.day, 0, 0, 0).isoformat() + "Z"
            end_of_today = datetime.datetime(now.year, now.month, now.day, 23, 59, 59).isoformat() + "Z"

            events_result = service.events().list(
                calendarId="primary",
                timeMin=start_of_today,
                timeMax=end_of_today,
                maxResults=max_results,
                singleEvents=True,
                orderBy="startTime"
            ).execute()

            events = events_result.get("items", [])
            if not events:
                return "No events scheduled for today."

            event_summary = []
            for event in events:
                start = event["start"].get("dateTime", event["start"].get("date"))
                summary = event.get("summary", "Untitled Event")
                
                # Format time cleanly for reading
                try:
                    dt = datetime.datetime.fromisoformat(start.replace("Z", "+00:00"))
                    time_str = dt.strftime("%I:%M %p")
                except Exception:
                    time_str = start # fallback to raw string
                    
                event_summary.append(f"- **{time_str}**: {summary}")

            return "\n".join(event_summary)
        except FileNotFoundError as fnf:
            return str(fnf)
        except Exception as e:
            return f"Error retrieving calendar events: {str(e)}"
