import os
from github import Github
from typing import List, Callable
from modules.base import BaseModule
from core.config import settings

# Try importing GitPython. If Git executable is missing, fail gracefully during tool call.
try:
    import git
    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False


class ProjectAutomator(BaseModule):
    """
    Module to automate project creation, local Git repository setup,
    boilerplate code writing, and pushing to a remote GitHub repository.
    """
    @property
    def name(self) -> str:
        return "ProjectAutomator"

    @property
    def description(self) -> str:
        return "Initialize local projects, git repositories, and push them to GitHub."

    def get_tools(self) -> List[Callable]:
        return [self.create_and_push_project]

    def create_and_push_project(
        self,
        project_name: str,
        base_dir: str,
        description: str = "A repository created by Jarvis.",
        is_private: bool = True
    ) -> str:
        """
        Creates a local directory, sets up git, creates boilerplate files (README.md, main.py),
        creates a corresponding remote GitHub repo, and pushes the code.

        Args:
            project_name: Name of the project (and GitHub repository).
            base_dir: Absolute path of the parent directory where the project directory will be created.
            description: Description of the GitHub repository.
            is_private: Whether the GitHub repository should be private.
        """
        if not GIT_AVAILABLE:
            return (
                "Error: Git command line executable was not found on your system PATH.\n"
                "Please install Git (from https://git-scm.com/) and verify it is added to PATH "
                "to use the project automation module."
            )

        token = settings.github_token
        if not token or token == "your_github_personal_access_token_here":
            return "Error: GITHUB_TOKEN is not set in the environment or configuration."

        # 1. Create Local Directory
        project_path = os.path.normpath(os.path.join(base_dir, project_name))
        if os.path.exists(project_path):
            return f"Error: Directory already exists at '{project_path}'."

        try:
            os.makedirs(project_path, exist_ok=True)
        except Exception as e:
            return f"Error creating directory: {str(e)}"

        # 2. Write Boilerplate Files
        readme_content = f"# {project_name}\n\n{description}\n\n*Created automatically by Jarvis.*"
        script_content = f'"""\nMain script for {project_name}\n"""\n\ndef main():\n    print("Hello from {project_name}!")\n\nif __name__ == "__main__":\n    main()\n'

        try:
            with open(os.path.join(project_path, "README.md"), "w", encoding="utf-8") as f:
                f.write(readme_content)
            with open(os.path.join(project_path, "main.py"), "w", encoding="utf-8") as f:
                f.write(script_content)
        except Exception as e:
            return f"Error writing project files: {str(e)}"

        # 3. Initialize Git Repository
        try:
            repo = git.Repo.init(project_path)
            # Add files and commit
            repo.index.add(["README.md", "main.py"])
            repo.index.commit("Initial commit from Jarvis")
            # Rename default branch to main
            repo.git.branch("-M", "main")
        except Exception as e:
            return f"Error initializing local git repository: {str(e)}"

        # 4. Create GitHub Repository and Push
        try:
            gh = Github(token)
            user = gh.get_user()
            
            # Check if repo already exists on GitHub
            try:
                user.get_repo(project_name)
                return f"Error: GitHub repository '{project_name}' already exists for this user."
            except Exception:
                pass  # Repo doesn't exist, which is expected
                
            gh_repo = user.create_repo(
                name=project_name,
                description=description,
                private=is_private,
                has_issues=True,
                has_wiki=False
            )
            
            # Configure Remote
            # Authenticated URL: https://<token>@github.com/<username>/<repo>.git
            authenticated_url = gh_repo.clone_url.replace("https://", f"https://{token}@")
            origin = repo.create_remote("origin", authenticated_url)
            
            # Push to GitHub
            origin.push("main")
            
            return f"Success! Project '{project_name}' created at '{project_path}' and pushed to GitHub: {gh_repo.html_url}"
        except Exception as e:
            return f"Error creating/pushing to GitHub repository: {str(e)}"
