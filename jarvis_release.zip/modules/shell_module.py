import subprocess
from typing import List, Callable
from modules.base import BaseModule
from core.security import security_manager

class SystemController(BaseModule):
    """
    Module for system access and local shell execution.
    Features a validation layer and Human-in-the-Loop checks for dangerous commands.
    """
    @property
    def name(self) -> str:
        return "SystemController"

    @property
    def description(self) -> str:
        return "Execute shell commands on the local machine safely."

    def get_tools(self) -> List[Callable]:
        return [self.run_shell_command]

    def run_shell_command(self, command: str) -> str:
        """
        Run a command in the local system shell and return the output.
        Sensitive or dangerous commands will require manual confirmation.
        
        Args:
            command: The exact shell command string to execute (e.g. 'dir', 'git status').
        """
        # 1. Validation check
        is_dangerous = security_manager.is_command_dangerous(command)
        
        # 2. Confirm if dangerous
        if is_dangerous:
            approved = security_manager.confirm_action(f"Execute potentially dangerous command: '{command}'")
            if not approved:
                return "Error: Command execution denied by user."
        
        # 3. Execute
        try:
            # Run the command with Windows shell options
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            output = ""
            if result.stdout:
                output += f"Output:\n{result.stdout}\n"
            if result.stderr:
                output += f"Errors:\n{result.stderr}\n"
            if not output:
                output = f"Command executed successfully with return code {result.returncode}."
                
            return output
        except subprocess.TimeoutExpired:
            return "Error: Command timed out after 30 seconds."
        except Exception as e:
            return f"Error executing command: {str(e)}"
