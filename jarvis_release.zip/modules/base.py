from abc import ABC, abstractmethod
from typing import List, Callable

class BaseModule(ABC):
    """
    Abstract base class for all capability modules in Jarvis.
    Ensures modularity by defining a standard registration and tool interface.
    """
    @property
    @abstractmethod
    def name(self) -> str:
        """Return the name of the module."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Return a description of what this module does."""
        pass

    @abstractmethod
    def get_tools(self) -> List[Callable]:
        """
        Return the list of python functions (tools) this module exposes.
        These functions will have descriptive docstrings and type hints,
        allowing the Gemini SDK to automatically generate tool schemas.
        """
        pass
