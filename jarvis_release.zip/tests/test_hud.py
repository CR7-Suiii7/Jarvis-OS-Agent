import pytest
from unittest.mock import MagicMock, patch
import sys

# Mock win32 modules for safety in non-Windows test runners if applicable
sys.modules["win32gui"] = MagicMock()
sys.modules["win32con"] = MagicMock()

from gui.hud import JarvisHUD

def test_hud_initialization():
    # Instantiate HUD class
    hud = JarvisHUD()
    
    # Assert properties match configurations
    assert hud.title() == "Jarvis HUD"
    assert hud.attributes("-topmost") == True
    
    # Verify label elements exist
    assert "System" in hud.labels
    assert "Gmail" in hud.labels
    assert "Calendar" in hud.labels
    assert "GitHub" in hud.labels
    
    # Clean up widget to release graphics memory
    hud.destroy()
