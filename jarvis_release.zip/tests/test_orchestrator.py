import pytest
from unittest.mock import MagicMock, patch
from core.orchestrator import JarvisCore
from modules.base import BaseModule
from google.genai import types

class DummyModule(BaseModule):
    @property
    def name(self) -> str:
        return "DummyModule"
        
    @property
    def description(self) -> str:
        return "A dummy testing module"
        
    def get_tools(self):
        return [self.dummy_action]
        
    def dummy_action(self, val: str) -> str:
        """Dummy action docstring."""
        return f"acted-{val}"

@patch("core.orchestrator.GeminiClient")
def test_orchestrator_tool_registration(mock_client_class):
    jc = JarvisCore()
    dm = DummyModule()
    jc.register_module(dm)
    
    assert "dummy_action" in jc.tools_map
    assert jc.tools_map["dummy_action"] == dm.dummy_action

@patch("core.orchestrator.GeminiClient")
def test_orchestrator_handle_query_no_tools(mock_client_class):
    # Setup mock query response
    mock_client = MagicMock()
    mock_client_class.return_value = mock_client
    
    mock_response = MagicMock(text="Hello user", function_calls=[])
    mock_client.query.return_value = mock_response
    
    jc = JarvisCore()
    res = jc.handle_query("Hi Jarvis")
    
    assert res == "Hello user"
    assert len(jc.history) == 2 # stores user query and final model reply

@patch("core.orchestrator.GeminiClient")
def test_orchestrator_handle_query_with_tool_loop(mock_client_class):
    mock_client = MagicMock()
    mock_client_class.return_value = mock_client
    
    # 1. First model invocation requests dummy_action tool call
    call = MagicMock(args={"val": "hello"})
    call.name = "dummy_action"
    mock_response_1 = MagicMock(function_calls=[call], text=None)

    
    # Mock candidates structures used inside the orchestrator for history recording
    mock_response_1.candidates = [MagicMock(content=MagicMock(parts=[]))]
    
    # 2. Second model invocation returns final message text
    mock_response_2 = MagicMock(function_calls=[], text="I performed dummy action and got acted-hello.")
    
    mock_client.query.side_effect = [mock_response_1, mock_response_2]
    
    jc = JarvisCore()
    dm = DummyModule()
    jc.register_module(dm)
    
    res = jc.handle_query("Run dummy action")
    
    assert "acted-hello" in res
    assert mock_client.query.call_count == 2
