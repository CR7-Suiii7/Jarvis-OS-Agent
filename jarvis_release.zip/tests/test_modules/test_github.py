import sys
from unittest.mock import MagicMock
# Mock git module to prevent initialization failures when git binary is not installed
sys.modules['git'] = MagicMock()

import os
import pytest
from unittest.mock import patch
from core.config import settings
from modules.github_module import ProjectAutomator

def test_github_module_properties():
    pa = ProjectAutomator()
    assert pa.name == "ProjectAutomator"
    assert "Initialize local projects" in pa.description
    assert len(pa.get_tools()) == 1

@patch("modules.github_module.os.makedirs")
@patch("modules.github_module.git.Repo.init")
@patch("modules.github_module.Github")
@patch("builtins.open")
@patch("modules.github_module.os.path.exists")
def test_create_and_push_project_success(
    mock_exists, mock_open, mock_github, mock_repo_init, mock_makedirs
):
    # Set dummy token in configuration
    settings.github_token = "dummy_token"
    mock_exists.return_value = False

    # Mock Github remote repo creation
    mock_gh_instance = MagicMock()
    mock_github.return_value = mock_gh_instance
    mock_user = MagicMock()
    mock_gh_instance.get_user.return_value = mock_user
    mock_user.get_repo.side_effect = Exception("Repo not found")
    
    mock_gh_repo = MagicMock(
        clone_url="https://github.com/user/test-repo.git",
        html_url="https://github.com/user/test-repo"
    )
    mock_user.create_repo.return_value = mock_gh_repo

    # Mock Git Repo structure
    mock_repo_instance = MagicMock()
    mock_repo_init.return_value = mock_repo_instance

    pa = ProjectAutomator()
    res = pa.create_and_push_project(
        project_name="test-repo",
        base_dir="c:/fake/path",
        description="test desc",
        is_private=True
    )

    assert "Success" in res
    mock_makedirs.assert_called_once()
    mock_repo_init.assert_called_once()
    mock_user.create_repo.assert_called_once_with(
        name="test-repo",
        description="test desc",
        private=True,
        has_issues=True,
        has_wiki=False
    )
    mock_repo_instance.create_remote.assert_called_once()
