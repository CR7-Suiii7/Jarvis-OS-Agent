import pytest
from unittest.mock import MagicMock, patch
from modules.shell_module import SystemController
from core.security import security_manager

def test_shell_module_properties():
    sc = SystemController()
    assert sc.name == "SystemController"
    assert "Execute shell commands" in sc.description
    assert len(sc.get_tools()) == 1

@patch("modules.shell_module.subprocess.run")
def test_run_safe_command(mock_run):
    # Set up mock command result
    mock_run.return_value = MagicMock(stdout="system active\n", stderr="", returncode=0)
    
    sc = SystemController()
    res = sc.run_shell_command("echo system active")
    
    assert "system active" in res
    mock_run.assert_called_once()

@patch("modules.shell_module.subprocess.run")
def test_run_dangerous_command_denied(mock_run):
    # Establish confirmation handler that denies the execution
    security_manager.set_confirm_callback(lambda _: False)
    
    sc = SystemController()
    res = sc.run_shell_command("rm -rf target_directory")
    
    assert "denied" in res
    mock_run.assert_not_called()
    
    # Reset confirmation handler
    security_manager._confirm_callback = None

@patch("modules.shell_module.subprocess.run")
def test_run_dangerous_command_approved(mock_run):
    # Establish confirmation handler that approves the execution
    security_manager.set_confirm_callback(lambda _: True)
    mock_run.return_value = MagicMock(stdout="deleted\n", stderr="", returncode=0)
    
    sc = SystemController()
    res = sc.run_shell_command("rm -rf target_directory")
    
    assert "deleted" in res
    mock_run.assert_called_once()
    
    # Reset confirmation handler
    security_manager._confirm_callback = None
