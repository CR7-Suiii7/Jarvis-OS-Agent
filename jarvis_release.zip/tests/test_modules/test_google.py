import pytest
from unittest.mock import patch, MagicMock
from modules.google_module import GoogleIntegrator

def test_google_module_properties():
    gi = GoogleIntegrator()
    assert gi.name == "GoogleIntegrator"
    assert "Manage and query Google" in gi.description
    assert len(gi.get_tools()) == 2

@patch("modules.google_module.GoogleIntegrator._get_credentials")
@patch("modules.google_module.build")
def test_fetch_unread_emails_success(mock_build, mock_get_credentials):
    mock_get_credentials.return_value = MagicMock()
    
    # Mock Gmail Service behavior
    mock_service = MagicMock()
    mock_build.return_value = mock_service
    
    mock_messages_resource = mock_service.users().messages()
    
    # Return 1 test message ID
    mock_messages_resource.list().execute.return_value = {
        "messages": [{"id": "msg123"}]
    }
    
    # Return test metadata and snippet
    mock_messages_resource.get().execute.return_value = {
        "id": "msg123",
        "snippet": "This is a test snippet.",
        "payload": {
            "headers": [
                {"name": "Subject", "value": "Test Subject"},
                {"name": "From", "value": "tester@example.com"}
            ]
        }
    }

    gi = GoogleIntegrator()
    res = gi.fetch_unread_emails(max_results=1)

    assert "Test Subject" in res
    assert "tester@example.com" in res
    assert "This is a test snippet." in res
    mock_build.assert_called_once_with("gmail", "v1", credentials=mock_get_credentials.return_value)

@patch("modules.google_module.GoogleIntegrator._get_credentials")
@patch("modules.google_module.build")
def test_list_today_events_success(mock_build, mock_get_credentials):
    mock_get_credentials.return_value = MagicMock()
    
    mock_service = MagicMock()
    mock_build.return_value = mock_service
    
    mock_events_resource = mock_service.events()
    
    # Return 1 dummy event
    mock_events_resource.list().execute.return_value = {
        "items": [
            {
                "summary": "Standup Meeting",
                "start": {"dateTime": "2026-06-03T10:00:00Z"}
            }
        ]
    }

    gi = GoogleIntegrator()
    res = gi.list_today_events()

    assert "Standup Meeting" in res
    mock_build.assert_called_once_with("calendar", "v3", credentials=mock_get_credentials.return_value)
