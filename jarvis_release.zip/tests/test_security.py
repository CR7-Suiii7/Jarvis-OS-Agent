import pytest
from core.security import security_manager

def test_is_command_dangerous():
    # Verify dangerous commands are correctly flagged
    assert security_manager.is_command_dangerous("rm -rf folder") is True
    assert security_manager.is_command_dangerous("sudo systemctl restart service") is True
    assert security_manager.is_command_dangerous("del /s /q directory") is True
    
    # Verify non-destructive commands pass validation
    assert security_manager.is_command_dangerous("git status") is False
    assert security_manager.is_command_dangerous("dir -la") is False
    assert security_manager.is_command_dangerous("echo hello") is False

def test_confirm_action_approve(monkeypatch):
    # Mock user input to return "yes"
    monkeypatch.setattr("builtins.input", lambda _: "yes")
    assert security_manager.confirm_action("Executing dangerous task") is True

def test_confirm_action_deny(monkeypatch):
    # Mock user input to return "no"
    monkeypatch.setattr("builtins.input", lambda _: "no")
    assert security_manager.confirm_action("Executing dangerous task") is False

def test_confirm_callback_override():
    # Verify customized callback executes successfully
    called = False
    def mock_callback(desc):
        nonlocal called
        called = True
        return True
        
    security_manager.set_confirm_callback(mock_callback)
    res = security_manager.confirm_action("Testing callback")
    
    assert called is True
    assert res is True
    
    # Clean up callback
    security_manager._confirm_callback = None
