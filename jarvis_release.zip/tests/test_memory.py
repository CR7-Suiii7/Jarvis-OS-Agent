import os
import json
import pytest
import sqlite3
import numpy as np
from unittest.mock import MagicMock, patch
from core.memory import MemoryManager

@pytest.fixture
def temp_memory_manager(tmp_path):
    db_path = tmp_path / "history.db"
    mem_path = tmp_path / "semantic_memory.json"
    style_path = tmp_path / "style_guide.json"
    
    # Mock LLM Client
    mock_client = MagicMock()
    
    manager = MemoryManager(
        db_path=str(db_path),
        memory_path=str(mem_path),
        style_path=str(style_path),
        llm_client=mock_client
    )
    return manager

def test_sqlite_logging(temp_memory_manager):
    # Log a successful command
    temp_memory_manager.log_action("command", "dir", success=True)
    # Log a failed project request
    temp_memory_manager.log_action("project", "create_and_push_project", success=False, error_message="Network Timeout")
    
    # Inspect database
    conn = sqlite3.connect(temp_memory_manager.db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT action_type, details, success, error_message FROM actions ORDER BY id ASC")
    rows = cursor.fetchall()
    conn.close()
    
    assert len(rows) == 2
    assert rows[0] == ("command", "dir", 1, "")
    assert rows[1] == ("project", "create_and_push_project", 0, "Network Timeout")


def test_get_failed_actions(temp_memory_manager):
    temp_memory_manager.log_action("command", "git status", success=True)
    temp_memory_manager.log_action("command", "git push", success=False, error_message="Authentication failed")
    
    failures = temp_memory_manager.get_failed_actions("command")
    assert len(failures) == 1
    assert failures[0]["details"] == "git push"
    assert failures[0]["error_message"] == "Authentication failed"

def test_style_guide_lifecycle(temp_memory_manager):
    # Verify default creation
    style = temp_memory_manager.get_style_guide()
    assert "naming_conventions" in style
    assert "documentation" in style
    
    # Verify refining guide with a mocked response
    mock_response = MagicMock(text='{\n"naming_conventions": "camelCase",\n"documentation": "no docs",\n"general_preferences": ["rule1"]\n}')
    temp_memory_manager.llm_client.client.models.generate_content.return_value = mock_response
    
    res = temp_memory_manager.refine_style_guide("class X:", "make naming conventions camelCase")
    
    assert "Style guide refined successfully" in res
    new_style = temp_memory_manager.get_style_guide()
    assert new_style["naming_conventions"] == "camelCase"
    assert new_style["general_preferences"] == ["rule1"]

def test_semantic_memory_vector_search(temp_memory_manager):
    # Dummy embedding dimensions (768 length)
    v_pref = [1.0] + [0.0] * 767
    v_query_match = [0.9] + [0.1] + [0.0] * 766
    v_query_mismatch = [0.0] + [1.0] + [0.0] * 766
    
    # Mock embedding generator
    def mock_embed(text):
        if "preference" in text:
            return v_pref
        elif "match" in text:
            return v_query_match
        return v_query_mismatch
        
    temp_memory_manager._get_embedding = mock_embed
    
    # Store a preference
    stored = temp_memory_manager.add_preference("This is my coding preference.")
    assert stored is True
    assert len(temp_memory_manager.memory_db) == 1
    
    # Retrieve with matching query (cosine similarity is high)
    matches = temp_memory_manager.get_relevant_preferences("match query", threshold=0.5)
    assert len(matches) == 1
    assert matches[0] == "This is my coding preference."
    
    # Retrieve with mismatch query (cosine similarity is low)
    no_matches = temp_memory_manager.get_relevant_preferences("other query", threshold=0.8)
    assert len(no_matches) == 0
