import math
import tkinter as tk

class EnergyOrb(tk.Canvas):
    """
    Futuristic pulsating energy orb widget drawn on a Tkinter Canvas.
    Renders rotating concentric geometric arcs and a central pulsating core.
    """
    def __init__(self, parent, size=300, bg_color="#000001", **kwargs):
        super().__init__(
            parent,
            width=size,
            height=size,
            bg=bg_color,
            bd=0,
            highlightthickness=0,
            **kwargs
        )
        self.size = size
        self.center = size // 2
        self.bg_color = bg_color
        
        # State parameters for animation
        self.angle = 0.0
        self.pulse_phase = 0.0
        self.pulse_speed = 0.05 # Resting default pulse speed
        
        # Begin rendering loop
        self.animate()

    def set_state(self, state: str) -> None:
        """
        Updates the pulse frequency and rotation metrics based on active assistant states.
        Valid states: 'idle', 'listening', 'thinking', 'speaking'
        """
        if state == "listening":
            self.pulse_speed = 0.14  # rapid pulse to show microphone active
        elif state == "thinking":
            self.pulse_speed = 0.08  # steady wave indicating reasoning loop
        elif state == "speaking":
            self.pulse_speed = 0.10  # talking vibration pattern
        else:
            self.pulse_speed = 0.04  # resting pulse

    def animate(self) -> None:
        self.delete("all")
        
        # Update metrics
        self.angle += 0.03
        self.pulse_phase += self.pulse_speed
        
        # Use sine function to model glowing size oscillation (bound between 0 and 1)
        pulse_factor = (math.sin(self.pulse_phase) + 1.0) / 2.0
        
        # 1. Background geometric crosshairs
        self.create_line(self.center - 140, self.center, self.center - 120, self.center, fill="#003366", width=1)
        self.create_line(self.center + 120, self.center, self.center + 140, self.center, fill="#003366", width=1)
        self.create_line(self.center, self.center - 140, self.center, self.center - 120, fill="#003366", width=1)
        self.create_line(self.center, self.center + 120, self.center, self.center + 140, fill="#003366", width=1)

        # 2. Concentric reference grid circle
        grid_r = 125
        self.create_oval(
            self.center - grid_r, self.center - grid_r,
            self.center + grid_r, self.center + grid_r,
            outline="#002244", width=1
        )

        # 3. Outer rotating rings & geometric arcs (clock-wise rotation)
        arc_r1 = 100
        self.create_arc(
            self.center - arc_r1, self.center - arc_r1,
            self.center + arc_r1, self.center + arc_r1,
            start=math.degrees(self.angle), extent=70,
            style=tk.ARC, outline="#00FFFF", width=2
        )
        self.create_arc(
            self.center - arc_r1, self.center - arc_r1,
            self.center + arc_r1, self.center + arc_r1,
            start=math.degrees(self.angle) + 180, extent=70,
            style=tk.ARC, outline="#00FFFF", width=2
        )
        
        # 4. Secondary counter-rotating arcs (counter clock-wise)
        arc_r2 = 112
        self.create_arc(
            self.center - arc_r2, self.center - arc_r2,
            self.center + arc_r2, self.center + arc_r2,
            start=math.degrees(-self.angle * 1.4), extent=50,
            style=tk.ARC, outline="#1E90FF", width=1, dash=(4, 2)
        )
        self.create_arc(
            self.center - arc_r2, self.center - arc_r2,
            self.center + arc_r2, self.center + arc_r2,
            start=math.degrees(-self.angle * 1.4) + 120, extent=50,
            style=tk.ARC, outline="#1E90FF", width=1, dash=(4, 2)
        )
        self.create_arc(
            self.center - arc_r2, self.center - arc_r2,
            self.center + arc_r2, self.center + arc_r2,
            start=math.degrees(-self.angle * 1.4) + 240, extent=50,
            style=tk.ARC, outline="#1E90FF", width=1, dash=(4, 2)
        )

        # 5. Pulsating outer energy rings
        outer_glow_r = 50 + int(15 * pulse_factor)
        self.create_oval(
            self.center - outer_glow_r, self.center - outer_glow_r,
            self.center + outer_glow_r, self.center + outer_glow_r,
            outline="#008080", width=1, dash=(10, 4)
        )

        mid_glow_r = 38 + int(8 * pulse_factor)
        self.create_oval(
            self.center - mid_glow_r, self.center - mid_glow_r,
            self.center + mid_glow_r, self.center + mid_glow_r,
            outline="#1E90FF", width=2
        )

        # 6. Central core sphere
        core_r = 25 + int(5 * pulse_factor)
        self.create_oval(
            self.center - core_r, self.center - core_r,
            self.center + core_r, self.center + core_r,
            fill="#00FFFF", outline="#FFFFFF", width=1
        )
        
        # Loop animation callback every 50ms (20 FPS target)
        self.after(50, self.animate)
