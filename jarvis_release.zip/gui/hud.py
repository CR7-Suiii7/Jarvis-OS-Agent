import os
import sys
import queue
import tkinter as tk
import customtkinter as ctk
import win32gui
import win32con

from gui.orb import EnergyOrb

# Configure CustomTkinter styles
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class JarvisHUD(ctk.CTk):
    """
    Heads-Up Display overlay interface for Jarvis.
    Initializes a floating, borderless, transparent Window overlay.
    """
    def __init__(self):
        super().__init__()
        
        # Transparent key (Windows will make this color click-through and invisible)
        self.trans_color = "#000001"
        
        # Basic Window Setup
        self.title("Jarvis HUD")
        self.geometry("450x600")
        self.overrideredirect(True)      # Remove title bar and window borders
        self.attributes("-topmost", True)  # Make floating (Always on Top)
        self.attributes("-transparentcolor", self.trans_color)
        self.config(bg=self.trans_color)
        
        # Variables to track window dragging
        self.drag_x = 0
        self.drag_y = 0
        
        # Track window visibility state
        self.visible = True

        # Thread-safe event queue and polling initializer
        self.update_queue = queue.Queue()

        # Construct UI Frames & Elements
        self.setup_ui()
        
        # Setup Window Styles via Win32 API
        self.apply_win32_styles()
        
        # Start queue checking loop
        self.check_queue()
        
        # Start hardware hotkey kill switch listener thread
        self.start_hotkey_listener()

    def setup_ui(self) -> None:
        # 1. Main container framing
        self.container = ctk.CTkFrame(self, fg_color="transparent", bg_color=self.trans_color)
        self.container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # 2. Central Energy Orb
        self.orb = EnergyOrb(self.container, size=285, bg_color=self.trans_color)
        self.orb.pack(pady=(10, 20))
        
        # 3. Status Action Text
        self.status_title = ctk.CTkLabel(
            self.container,
            text="AWAITING COMMAND...",
            font=ctk.CTkFont(family="Courier New", size=18, weight="bold"),
            text_color="#00FFFF",
            fg_color="transparent"
        )
        self.status_title.pack(pady=(0, 15))
        
        # 4. Status Indicator Panel Card
        self.info_panel = ctk.CTkFrame(
            self.container,
            fg_color="#001122",
            border_color="#00FFFF",
            border_width=1,
            corner_radius=8,
            bg_color=self.trans_color
        )
        self.info_panel.pack(fill="x", padx=15, pady=5)
        
        # Grid spacing configuration
        self.info_panel.columnconfigure(0, weight=1)
        
        self.labels = {}
        indicators = [
            ("System", "System: Active", 0),
            ("Gmail", "Gmail: 0 Unread", 1),
            ("Calendar", "Calendar: Active", 2),
            ("GitHub", "GitHub: Syncing", 3)
        ]
        
        for name, value, row in indicators:
            lbl = ctk.CTkLabel(
                self.info_panel,
                text=value,
                font=ctk.CTkFont(family="Courier New", size=14),
                text_color="#00BFFF",
                anchor="w",
                fg_color="transparent"
            )
            lbl.grid(row=row, column=0, padx=25, pady=6, sticky="w")
            self.labels[name] = lbl

        # Bind click-drag gestures to movable panel sections to allow HUD repositioning
        self.info_panel.bind("<Button-1>", self.start_drag)
        self.info_panel.bind("<B1-Motion>", self.do_drag)
        self.status_title.bind("<Button-1>", self.start_drag)
        self.status_title.bind("<B1-Motion>", self.do_drag)

    def apply_win32_styles(self) -> None:
        self.update()
        hwnd = self.winfo_id()
        
        # Retrieve active extended styles
        ex_style = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
        
        # Apply WS_EX_LAYERED style for transparent color integration
        win32gui.SetWindowLong(
            hwnd,
            win32con.GWL_EXSTYLE,
            ex_style | win32con.WS_EX_LAYERED
        )

    def start_drag(self, event) -> None:
        self.drag_x = event.x
        self.drag_y = event.y

    def do_drag(self, event) -> None:
        # Move window matching cursor relative offsets
        x = self.winfo_x() + (event.x - self.drag_x)
        y = self.winfo_y() + (event.y - self.drag_y)
        self.geometry(f"+{x}+{y}")

    def update_hud_status(self, module_name: str, status_text: str) -> None:
        """
        Thread-safe method called by worker threads to enqueue a status text update.
        """
        self.update_queue.put(("status", module_name, status_text))

    def update_orb_state(self, state: str) -> None:
        """
        Thread-safe method called by worker threads to enqueue an orb state update.
        """
        self.update_queue.put(("orb", state, ""))

    def check_queue(self) -> None:
        """
        Regularly polls the queue from the main GUI thread to perform updates safely.
        """
        try:
            while not self.update_queue.empty():
                action_type, target, value = self.update_queue.get_nowait()
                
                if action_type == "status":
                    if target == "title":
                        self.status_title.configure(text=value.upper())
                    elif target in self.labels:
                        self.labels[target].configure(text=f"{target}: {value}")
                        
                elif action_type == "orb":
                    self.orb.set_state(target)
                    
                elif action_type == "toggle_visibility":
                    if self.visible:
                        self.withdraw()
                        self.visible = False
                    else:
                        self.deiconify()
                        self.attributes("-topmost", True)
                        self.visible = True
                    
                self.update_queue.task_done()
        except queue.Empty:
            pass
            
        # Poll again in 80ms (aligns with pulse animation timing)
        self.after(80, self.check_queue)

    def start_hotkey_listener(self) -> None:
        """Spawns background listener thread for Win32 keyboard global hotkey."""
        import threading
        hotkey_thread = threading.Thread(target=self.hotkey_listener_worker, daemon=True)
        hotkey_thread.start()

    def hotkey_listener_worker(self) -> None:
        """
        Background listener task registering Ctrl+Alt+Q global hotkey via Win32.
        Enqueues toggle actions securely upon activation.
        """
        import ctypes
        import ctypes.wintypes
        
        user32 = ctypes.windll.user32
        
        # Ctrl+Alt+Q: MOD_CONTROL (0x0002) | MOD_ALT (0x0001), virtual key Q (0x51)
        # Unique registration ID: 99
        if not user32.RegisterHotKey(None, 99, 0x0002 | 0x0001, 0x51):
            print("[Warning] Failed to register global hardware hotkey Ctrl+Alt+Q")
            return
            
        try:
            msg = ctypes.wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
                if msg.message == win32con.WM_HOTKEY:
                    if msg.wParam == 99:
                        self.update_queue.put(("toggle_visibility", "", ""))
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
        except Exception as e:
            pass
        finally:
            user32.UnregisterHotKey(None, 99)


