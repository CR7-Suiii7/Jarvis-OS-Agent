import io
import logging
import speech_recognition as sr

# Try importing faster-whisper. Fallback to API if missing.
try:
    from faster_whisper import WhisperModel
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False

logger = logging.getLogger(__name__)

class Listener:
    """
    Speech-to-Text (STT) engine for Jarvis.
    Uses faster-whisper for local-only, low-latency speech recognition.
    Gracefully falls back to Google Speech API if local Whisper fails or is offline,
    and falls back to keyboard text input if microphone resources are missing.
    """
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.microphone = None
        self.whisper_model = None
        
        try:
            self.microphone = sr.Microphone()
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.8)
        except Exception as e:
            logger.warning(
                f"Microphone initialization failed: {e}. "
                "Jarvis will operate in console-only text input mode."
            )

        # Initialize local Whisper model
        if WHISPER_AVAILABLE:
            try:
                logger.info("Loading local faster-whisper model (tiny)...")
                # Using 'tiny' on CPU for speed and low memory impact
                self.whisper_model = WhisperModel("tiny", device="cpu", compute_type="float32")
                logger.info("Local faster-whisper model loaded successfully.")
            except Exception as e:
                logger.error(f"Failed to load local faster-whisper model: {e}. Falling back to API.")

    def listen(self) -> str:
        """
        Listens to microphone input and transcribes it using local faster-whisper
        or Google Speech Recognition fallback.
        """
        if not self.microphone:
            try:
                return input("\n[You (Console)]: ").strip()
            except (KeyboardInterrupt, EOFError):
                return "exit"

        print("\n[Listening...]")
        try:
            with self.microphone as source:
                audio = self.recognizer.listen(source, timeout=6.0, phrase_time_limit=12.0)
            
            print("[Processing...]")
            
            # Attempt local faster-whisper transcription
            if self.whisper_model:
                try:
                    wav_io = io.BytesIO(audio.get_wav_data())
                    segments, info = self.whisper_model.transcribe(wav_io, beam_size=3)
                    query = " ".join(segment.text for segment in segments).strip()
                    print(f"[You (Voice - Local Whisper)]: {query}")
                    return query
                except Exception as we:
                    logger.error(f"Local Whisper transcription failed: {we}. Trying API...")

            # Utilize standard Google Speech API fallback
            query = self.recognizer.recognize_google(audio)
            print(f"[You (Voice - API Fallback)]: {query}")
            return query
        except sr.WaitTimeoutError:
            return ""
        except sr.UnknownValueError:
            print("[Jarvis: Did not catch that, please repeat...]")
            return ""
        except sr.RequestError as e:
            logger.error(f"Speech recognition service issue: {e}")
            try:
                return input("\n[You (Console - service issue)]: ").strip()
            except (KeyboardInterrupt, EOFError):
                return "exit"
        except Exception as e:
            logger.error(f"Error during listener capture: {e}")
            try:
                return input("\n[You (Console - fallback)]: ").strip()
            except (KeyboardInterrupt, EOFError):
                return "exit"
            
    def listen_raw_confirm(self) -> bool:
        """
        Listen specifically for a yes/no confirmation via microphone.
        """
        if not self.microphone:
            try:
                response = input("Confirm? (yes/no) [no]: ").strip().lower()
                return response in ["y", "yes", "proceed", "approve"]
            except (KeyboardInterrupt, EOFError):
                return False
        
        print("\n[Confirm by saying 'yes' / 'proceed' or 'no' / 'cancel'...]")
        try:
            with self.microphone as source:
                audio = self.recognizer.listen(source, timeout=5.0, phrase_time_limit=5.0)
            
            if self.whisper_model:
                try:
                    wav_io = io.BytesIO(audio.get_wav_data())
                    segments, _ = self.whisper_model.transcribe(wav_io, beam_size=1)
                    query = "".join(segment.text for segment in segments).strip().lower()
                    print(f"[You (Voice)]: {query}")
                    return query in ["yes", "proceed", "y", "approve", "ok"]
                except Exception:
                    pass

            query = self.recognizer.recognize_google(audio).strip().lower()
            print(f"[You (Voice)]: {query}")
            return query in ["yes", "proceed", "y", "approve", "ok"]
        except Exception:
            try:
                response = input("Confirm? (yes/no) [no]: ").strip().lower()
                return response in ["y", "yes", "proceed", "approve"]
            except (KeyboardInterrupt, EOFError):
                return False

