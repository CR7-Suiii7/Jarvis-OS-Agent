import logging
import pyttsx3
from core.config import settings

logger = logging.getLogger(__name__)

class Speaker:
    """
    Text-to-Speech (TTS) engine for Jarvis using pyttsx3.
    Operates locally and offline.
    """
    def __init__(self):
        try:
            self.engine = pyttsx3.init()
            # Set properties based on settings
            self.engine.setProperty("rate", settings.tts_rate)
            self.engine.setProperty("volume", settings.tts_volume)
            
            # Find a default voice (e.g. English)
            voices = self.engine.getProperty("voices")
            if voices:
                # Typically index 0 is Microsoft David (male) and 1 is Zira (female) on Windows
                self.engine.setProperty("voice", voices[0].id)
        except Exception as e:
            logger.error(f"Failed to initialize pyttsx3 TTS engine: {e}")
            self.engine = None

    def speak(self, text: str) -> None:
        """
        Speak the given text using the local TTS voice engine.
        Also prints the text to the console.
        """
        print(f"\n[Jarvis]: {text}")
        if self.engine:
            try:
                self.engine.say(text)
                self.engine.runAndWait()
            except Exception as e:
                logger.error(f"Error during audio speech playback: {e}")
